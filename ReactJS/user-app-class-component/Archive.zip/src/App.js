
import './App.css';

import UserApp from './components/UserApp';

function App() {
  return (
    <div className="App">
      {/* <Login /> */}

      {/* <Registration /> */}

      <UserApp />
    </div>
  );
}

export default App;
